class Enemy {
  
}