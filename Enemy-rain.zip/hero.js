class Hero {
  
}